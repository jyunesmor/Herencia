package entidades;

public class lavadora extends electrodomestico{
    protected int carga;

    public int getCarga() {
        return carga;
    }
    public void setCarga(int carga) {
        this.carga = carga;
    }
    public lavadora(){
    }

    public lavadora(int precio, String color, String consumoElectrico, int peso, int carga) {
        super(precio, color, consumoElectrico, peso);
        this.carga = carga;
    }

    public void crearlavadora(){
        super.crearElectrodomestico();
        System.out.println("cual es su carga?");
        int CAP = leer.nextInt();
        setCarga(CAP);
        setPrecioF();
    }
    public void setPrecioF(){
        int precioF = super.setPrecioFinal(this.consumoElectrico,this.peso);
        if(this.carga >= 30){
            precioF = precioF + 500;
        }
        setPrecio(precioF);
    }

    @Override
    public String toString() {
        return "lavadora{" +
                "carga=" + carga +
                ", precio=" + precio +
                ", color='" + color + '\'' +
                ", consumoElectrico='" + consumoElectrico + '\'' +
                ", peso=" + peso +
                '}';
    }
}
