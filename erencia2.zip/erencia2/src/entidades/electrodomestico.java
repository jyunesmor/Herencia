package entidades;

import java.util.Scanner;

public class electrodomestico {
    protected Scanner leer = new Scanner(System.in);
    protected int precio;
    protected String color;
    protected String consumoElectrico;
    protected int peso;

    public electrodomestico() {

    }

    protected void crearElectrodomestico(){
        System.out.println("porfavor introducir los datos del electrodomestico");
        System.out.println("cual es su consumo electrico? (de la A a la F solamente)");
        String consumo = leer.nextLine();
        setConsumoElectrico(consumo);
        System.out.println("cual es su color? (blanco, negro, rojo, azul o gris)");
        String pigmentacion = leer.nextLine();
        setColor(pigmentacion);
        System.out.println("cual es su peso?");
        int weight = leer.nextInt();
        setPeso(weight);
        setPrecio(1000);
        int precioFinal = setPrecioFinal(consumo,weight);
        setPrecio(precioFinal);
    }

    protected int setPrecioFinal(String letra, int peso){
        int vol1 = 0;
        switch (letra){
            case "A":
                vol1 = 1000;
                break;
            case "B":
                vol1 = 800;
                break;
            case "C":
                vol1 = 600;
                break;
            case "D":
                vol1 = 500;
                break;
            case "E":
                vol1 = 300;
                break;
            case "F":
                vol1 = 100;
                break;
        }
        int vol2 = 0;
        if (peso > 0 && peso < 20){
            vol2 = 100;
        }else if (peso > 19 && peso < 50){
            vol2 = 500;
        }else if (peso > 49 && peso < 80){
            vol2 = 800;
        }else if (peso > 79){
            vol2 = 1000;
        }
        int PF = vol1 + vol2;
    return PF;}

    public electrodomestico(int precio, String color, String consumoElectrico, int peso) {
        this.precio = precio;
        this.color = color;
        this.consumoElectrico = consumoElectrico;
        this.peso = peso;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        String pigment = comprobarColor(color);
        this.color = pigment;
    }

    public String getConsumoElectrico() {
        return consumoElectrico;
    }

    public void setConsumoElectrico(String consumoElectrico) {
        String energy = " ";
        energy = comprobarConsumoEnergetico(consumoElectrico);
        this.consumoElectrico = energy;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    private String comprobarConsumoEnergetico(String letra){
        String energy = " ";
        if(letra.equalsIgnoreCase("A") || letra.equalsIgnoreCase("B") || letra.equalsIgnoreCase("C") || letra.equalsIgnoreCase("D") || letra.equalsIgnoreCase("E") || letra.equalsIgnoreCase("F")){
            energy = letra.toUpperCase();
        }else{
            energy = "F";
        }
        return energy;
    }
    private String comprobarColor(String color){
        String pigment = " ";
        if(color.equalsIgnoreCase("blanco") || color.equalsIgnoreCase("negro") || color.equalsIgnoreCase("rojo") || color.equalsIgnoreCase("azul") || color.equalsIgnoreCase("gris")){
            pigment = color.toUpperCase();
        }else{
            pigment = "BLANCO";
        }
        return pigment;
    }
}
