package entidades;

public class Television extends electrodomestico{
    protected boolean TDT = false;
    protected double pulgadas;

    public Television() {

    }

    public Television(int precio, String color, String consumoElectrico, int peso, boolean TDT, double pulgadas) {
        super(precio, color, consumoElectrico, peso);
        this.TDT = TDT;
        this.pulgadas = pulgadas;
    }

    public boolean isTDT() {
        return TDT;
    }

    public void setTDT(boolean TDT) {
        this.TDT = TDT;
    }

    public double getPulgadas() {
        return pulgadas;
    }

    public void setPulgadas(double pulgadas) {
        this.pulgadas = pulgadas;
    }

    public void crearTelevisor(){
        super.crearElectrodomestico();
        System.out.println("cual es la resolucion del televisor");
        double pulgada = leer.nextDouble();
        setPulgadas(pulgada);
        System.out.println("tiene TDT el televisor");
        boolean f = true;
        while (f) {
            String discu = leer.nextLine();
            if (discu.equalsIgnoreCase("si") || discu.equalsIgnoreCase("yes")){
                setTDT(true);
                f = false;
            }else if (discu.equalsIgnoreCase("no")) {
                setTDT(false);
                f= false;
            }else{
                System.out.println("esa no es una opcion");
            }
        }
        precioFinal2();
    }
    public void precioFinal2(){
        double precioF = super.setPrecioFinal(this.consumoElectrico,this.peso);

        if (this.TDT){
            precioF = precioF + 500;
        }
        System.out.println(precioF);
        double porcentaje30 = precioF * 0.3;
        System.out.println(porcentaje30);
        if (this.pulgadas >= 40){
            precioF = precioF + porcentaje30;
        }
        setPrecio((int) precioF);
    }
    @Override
    public String toString() {
        return "Television{" +
                "TDT=" + TDT +
                ", pulgadas=" + pulgadas +
                ", precio=" + precio +
                ", color='" + color + '\'' +
                ", consumoElectrico='" + consumoElectrico + '\'' +
                ", peso=" + peso +
                '}';
    }
}
