package servicios;

import entidades.*;
import entidades.Television;
import java.util.ArrayList;
import java.util.Scanner;

public class menu {
    Scanner leer = new Scanner(System.in);
    public void Menu(ArrayList<lavadora>wastmachines,ArrayList<Television>TV,ArrayList<electrodomestico>electra){
        int init = 0;
        while(init != 6){
            System.out.println("menu de registro de inventario de electrodomesticos");
            System.out.println("1.Registro de lavadoras");
            System.out.println("2.Registro de televisores");
            System.out.println("3.lista de lavadoras");
            System.out.println("4.lista de televisores");
            System.out.println("5.valores de los inventarios");
            System.out.println("6.salida del sistema");
            init = leer.nextInt();
            switch (init){
                case 1:
                    lavadora lavanda = new lavadora();
                    lavanda.crearlavadora();
                    wastmachines.add(lavanda);
                    electra.add(lavanda);
                    break;
                case 2:
                    Television Digi = new Television();
                    Digi.crearTelevisor();
                    TV.add(Digi);
                    electra.add(Digi);
                    break;
                case 3:
                    for (lavadora aux: wastmachines){
                        System.out.println(aux.toString());
                    }
                    break;
                case 4:
                    for (Television aux: TV){
                        System.out.println(aux.toString());
                    }
                    break;
                case 5:
                    System.out.println("1.lista de lavadoras");
                    System.out.println("2.lista de televisores");
                    System.out.println("3.valor total de inventario");
                    int a = 0;
                    a = leer.nextInt();
                    switch(a){
                        case 1:
                            int b = 0;
                            for (lavadora aux: wastmachines){
                                System.out.println(aux.toString());
                                b = b + aux.getPrecio();
                            }
                            System.out.println("el valor total del inventario de lavadoras es de " + b);
                            break;
                        case 2:
                            int c = 0;
                            for (Television aux: TV){
                                System.out.println(aux.toString());
                                c = c + aux.getPrecio();
                            }
                            System.out.println("el valor total del inventario de televisores es de " + c);
                            break;
                        case 3:
                            b = 0;
                            c = 0;
                            int d = 0;
                            for (lavadora aux: wastmachines){
                                System.out.println(aux.toString());
                                b = b + aux.getPrecio();
                            }
                            for (Television aux: TV){
                                System.out.println(aux.toString());
                                c = c + aux.getPrecio();
                            }
                            for (electrodomestico aux: electra) {
                                System.out.println(aux.toString());
                                d = d + aux.getPrecio();
                            }
                            System.out.println("el valor total del inventario es de " + d);
                            System.out.println("Labadoras: " + b);
                            System.out.println("Televisores: " + c);
                            break;
                    }
                    break;
                case 6:
                    System.out.println("muy bien, grasias por preferirnos");
                    break;
            }
        }

    }

}
