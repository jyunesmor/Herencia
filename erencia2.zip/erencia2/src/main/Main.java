package main;
import entidades.*;
import servicios.menu;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] arg){
        ArrayList<lavadora> wastmachine = new ArrayList<>();
        ArrayList<Television> tv = new ArrayList<>();
        ArrayList<electrodomestico> electra = new ArrayList<>();
        menu MENU = new menu();
        MENU.Menu(wastmachine,tv, electra);
    }
}
